﻿<?php
include("../includes/config.php");
include("../includes/functions.php");
session_start();
$db = @mysqli_connect($conf['host'], $conf['user'], $conf['pass'], $conf['name']);
mysqli_query($db, 'SET NAMES utf8');

$confUrl = $conf['url'];

$resultSettings = mysqli_fetch_row(mysqli_query($db, getSettings($querySettings)));

// If captcha is enabled
if($resultSettings[9]) {
	if($_POST['captcha'] !== "{$_SESSION['captcha']}" || empty($_POST['captcha'])) {
		echo '<div class="container-short"><div class="info">Sorry but the captcha is invalid.</div></div>';
		return;
	}
}

$postData = array('longUrl' => $_POST['short'], 'key' => $resultSettings[1]); // prepare the array for JSON encoding
$jsonData = json_encode($postData); // encode to JSON format

$curlObj = curl_init();

curl_setopt($curlObj, CURLOPT_URL, 'https://www.googleapis.com/urlshortener/v1/url?key='.$resultSettings[1]);
curl_setopt($curlObj, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($curlObj, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($curlObj, CURLOPT_HEADER, 0);
curl_setopt($curlObj, CURLOPT_HTTPHEADER, array('Content-type:application/json'));
curl_setopt($curlObj, CURLOPT_POST, 1);
curl_setopt($curlObj, CURLOPT_POSTFIELDS, $jsonData);

$response = curl_exec($curlObj);

// JSON string to object format
$json = json_decode($response);
if(empty($json->id)) {
	echo '<div class="container-short"><div class="info">Sorry but the link you have entered is not valid.</div></div>';
	$x = 1;
} else {
	//echo $json->id;
	//echo $json->longUrl;
	$gid = str_replace(array('http://goo.gl/', 'https://goo.gl/'), array('', ''), $json->id); // strip the goo.gl url and get the id alone
	if(ctype_alnum($_POST['custom']) || $_POST['custom'] == '') { // verify if the Alias is only letters+-numbers or if it empty/not set.
		if(!empty($_POST['custom'])) { // verify if the custom input is set
			if(verifyAlias('gid', 'alias', $gid, $_POST['custom']) == 0 && $_POST['custom'] !== 'disclaimer' && $_POST['custom'] !== 'privacy' && $_POST['custom'] !== 'contact' && $_POST['custom'] !== 'admin' && $_POST['custom'] !== 'api' && $_POST['custom'] !== 'welcome' && $_POST['custom'] !== 'tos' && $_POST['custom'] !== 'latest' && $_POST['custom'] !== 'stats' && $_POST['custom'] !== 'short') { // verify if the alias already exists or have the same value as the `gid`
				$query = sprintf("INSERT INTO links (`url`, `gid`, `alias`, `date`) VALUES ('%s', '%s', '%s', '%s')",
				mysqli_real_escape_string($db, $json->longUrl),
				mysqli_real_escape_string($db, $gid),
				mysqli_real_escape_string($db, $_POST['custom']),
				mysqli_real_escape_string($db, date("Y-m-d H:i:s")));
				mysqli_query($db, $query);
			} else {
				echo '<div class="container-short"><div class="info">The current link can\'t have an alias.</div></div>';
				$x = 1;
			}
		} else {
			if(verifyId('gid', $gid) == 0) { // Check if Google Shortened ID exists in the database
				$query = sprintf("INSERT INTO links (`url`, `gid`, `alias`, `date`) VALUES ('%s', '%s', '%s', '%s')",
				mysqli_real_escape_string($db, $json->longUrl),
				mysqli_real_escape_string($db, $gid),
				mysqli_real_escape_string($db, ''),
				mysqli_real_escape_string($db, date("Y-m-d H:i:s")));
				mysqli_query($db, $query);
			}
		}
	} else {
		echo '<div class="container-short"><div class="info">The alias must consist only from letters and numbers.</div></div>';
		$x = 1;
	}
}
mysqli_close($db);
?>
<?php
// OUTPUT THE RESULT
if($x !== 1) { // Check if there is no error to display the content
	echo '<div class="container-short"><div class="short-container" id="focus">';
		if(!empty($_POST['custom'])) {
			echo '<div class="text-inputs">Custom Url:</div><input class="select" type="text" value="'.$confUrl.'/'.$_POST['custom'].'" readonly="readonly" /><br />';
		}
		echo '<div class="text-inputs">Shortened Url:</div><input class="select" type="text" value="'.$confUrl.'/'.$gid.'" readonly="readonly" /><br />';
		echo '<div class="text-inputs">Stats Url:</div><input class="select" type="text" value="'.$confUrl.'/stats/&url='.$gid.'" readonly="readonly" /><br />';
		echo '<div class="text-inputs">Original Url:</div><input class="select" type="text" value="'.$json->longUrl.'" readonly="readonly" /><br />';
		echo '<div class="text-inputs">QR Code</div><img src="http://chart.googleapis.com/chart?cht=qr&chs=150x150&choe=UTF-8&chld=H|0&chl='.$confUrl.'/'.$gid.'" />';
	echo '</div></div>';
}
?>