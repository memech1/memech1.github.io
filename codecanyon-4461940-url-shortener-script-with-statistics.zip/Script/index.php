<?php
require_once('./includes/config.php');
require_once('./includes/skins.php');
require_once('./includes/functions.php');

$db = @mysqli_connect($conf['host'], $conf['user'], $conf['pass'], $conf['name']);
mysqli_query($db, 'SET NAMES utf8');

if(!$db) {	
	echo "Failed to connect to MySQL: (" . mysqli_connect_errno() . ") " . mysqli_connect_error();
}

if(isset($_GET['a']) && isset($action[$_GET['a']])) {
	$page_name = $action[$_GET['a']];
} else {
	$page_name = 'welcome';
}

require_once("./sources/{$page_name}.php");

$confUrl = $conf['url'];

# Seteaza preferinta formatului temperaturii
if($_GET['f'] == 'f') {
	setcookie("format", 'fahrenhite', $time);	
	$TMPL['cf'] = 'f';
	$TMPL['f'] = 'c';
} elseif($_GET['f'] == 'c') {
	setcookie("format", 'celsius', $time);	
	$TMPL['cf'] = 'c';
	$TMPL['f'] = 'f';
} elseif($_COOKIE['format'] == '') {
	$TMPL['cf'] = 'c';
	$TMPL['f'] = 'f';
} elseif($_COOKIE['format'] == 'fahrenhite') {
	$TMPL['cf'] = 'f';
	$TMPL['f'] = 'c';
} elseif($_COOKIE['format'] == 'celsius') {
	$TMPL['cf'] = 'c';
	$TMPL['f'] = 'f';
}

$cookieFormat = $TMPL['cf']; # Seteaza variabila cookies format, ca s-o pot folosi si in rows

# Seteaza formatul pentru Tipsy
$TMPL['cfname'] = str_replace(array('c', 'f'), array('celsius', 'fahrenhite'), $cookieFormat);
if($TMPL['cfname'] == 'celsius') {
	$TMPL['fname'] = str_replace(array('f', 'c'), array('celsius', 'fahrenhite'), $cookieFormat);
} else {
	$TMPL['fname'] = str_replace(array('c', 'f'), array('fahrenhite', 'celsius'), $cookieFormat);
}

$TMPL['content'] = PageMain();

$resultSettings = mysqli_fetch_row(mysqli_query($db, getSettings($querySettings)));

$TMPL['twitterFooter'] = $resultSettings[6];
$TMPL['facebookFooter'] = $resultSettings[7];
$TMPL['gplusFooter'] = $resultSettings[8];

$TMPL['siteTitle'] = $resultSettings[0];
$TMPL['footer'] = $resultSettings[0];
$TMPL['url'] = $conf['url'];
$TMPL['year'] = date('Y');

if($_GET['a'] == 'redirect') { // Change the body file if the redirect is enabled
$skin = new skin('frame');
} else {
$skin = new skin('wrapper');
}
echo $skin->make();

mysqli_close($db);
?>