<?php
function PageMain() {
	global $TMPL, $db, $confUrl;
	$resultSettings = mysqli_fetch_row(mysqli_query($db, getSettings($querySettings)));
	
	if(ctype_alnum($_GET['a'])) {
		$query = "SELECT * FROM links WHERE `gid` = '".$_GET['a']."' OR `alias` = '".$_GET['a']."'";
		$result = mysqli_fetch_row(mysqli_query($db, $query));

		header('Location: '.$result[1]);
		
		if($resultSettings[5] == '0') { // If frame is disabled, redirect the user directly
			if($result[0]) {								
				header('Location: http://goo.gl/'.$result[2]);
			}
		} else { // If frame is enabled, send the user to frame
			if($result[0]) {
				header('Location: '.$confUrl.'/redirect/&url='.$_GET['a']);
			}
		}
	}
	
	$TMPL['url'] = $confUrl;
	$TMPL['title'] = $resultSettings[0];
	
	$TMPL['ad1'] = $resultSettings[2];
	$TMPL['ad2'] = $resultSettings[3];
	
	if($resultSettings[9]) {
		// Captcha
		$TMPL['captcha'] = '<div class="modal-captcha"><input type="text" name="captcha" placeholder="Captcha" class="captcha" id="captcha" autocomplete="off"></div>
		<span class="register-captcha" id="captcha-register"><img src="'.$confUrl.'/captcha.php" /></span>';
	}
	
	$skin = new skin('welcome/content');
	return $skin->make();
}
?>