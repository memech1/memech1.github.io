<?php
function PageMain() {
	global $TMPL, $db, $confUrl;
	$resultSettings = mysqli_fetch_row(mysqli_query($db, getSettings($querySettings)));
		
	$TMPL_old = $TMPL; $TMPL = array();
	$skin = new skin('latest/latest'); $latest = '';
	
	$query = "SELECT * from `links` ORDER BY `id` DESC LIMIT 0, 25";
	$result = mysqli_query($db, $query);
	
	$class = true;
	while($TMPL = mysqli_fetch_assoc($result)) {
		if($class == true) {
			$TMPL['class'] = 'doi';
			$class = false;
		} else {
			$TMPL['class'] = 'unu';
			$class = true;
		}
		$TMPL['url'] = (strlen($TMPL['url']) > 70) ? substr($TMPL['url'], 0, 70).'...' : $TMPL['url'];
		$TMPL['link'] = $confUrl.'/'.$TMPL['gid'];
		$TMPL['stats'] = $confUrl.'/stats/&url='.$TMPL['gid'];
		$latest .= $skin->make();
	}
	
	$TMPL = $TMPL_old; unset($TMPL_old);
	$TMPL['latest'] = $latest;
		
	$TMPL['title'] = $resultSettings[0].' - Latest';

	$skin = new skin('latest/content');
	return $skin->make();
}
?>