<?php
function PageMain() {
	global $TMPL, $db, $confUrl;
	
	if(!isset($_GET['url'])) {
		header('Location: '.$confUrl);
	}
	
	$resultSettings = mysqli_fetch_row(mysqli_query($db, getSettings($querySettings)));
		
	$TMPL_old = $TMPL; $TMPL = array();
	$skin = new skin('redirect/rows'); $all = '';
	
	if(ctype_alnum($_GET['url'])) { // Daca SHORT-ul este ALIAS-ul unic (adica litere +- cifre)
		$query = "SELECT * FROM links WHERE `gid` = '".$_GET['url']."' OR `alias` = '".$_GET['url']."'";
		$result = mysqli_fetch_row(mysqli_query($db, $query));
		
		if($resultSettings[5] == '0') { // Daca nu este activat frame-ul, redirectioneaza direct
			header('Location: http://goo.gl/'.$result[2]);
		}
		
		$TMPL['url'] = 'http://goo.gl/'.$result[2];
	}
	$TMPL['localurl'] = $confUrl;
	$TMPL['ads3'] = $resultSettings[4];
	
	$all .= $skin->make();
	
	$TMPL = $TMPL_old; unset($TMPL_old);
	$TMPL['rows'] = $all;
	
	$TMPL['url'] = $confUrl;
	$TMPL['title'] = $resultSettings[0].' - '.$result[1];
	
	$skin = new skin('redirect/content');
	return $skin->make();
}
?>