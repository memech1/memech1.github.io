<?php
function PageMain() {
	global $TMPL, $db, $confUrl;
	if(!isset($_GET['url'])) {
		header('Location: '.$confUrl);
	}
	$resultSettings = mysqli_fetch_row(mysqli_query($db, getSettings($querySettings)));
	
	$TMPL_old = $TMPL; $TMPL = array();	
	if(ctype_alnum($_GET['url'])) {
		$query = sprintf("SELECT * FROM `links` WHERE `gid` = '%s' || `alias` = '%s'",
						mysqli_real_escape_string($db, $_GET['url']),
						mysqli_real_escape_string($db, $_GET['url']));
		$result = mysqli_fetch_row(mysqli_query($db, $query));
		
		if($result[0]) {
			$skin = new skin('stats/rows'); $all = '';
			
			$TMPL['pageTitle'] = '<div class="stats-for">Stats for: '.$result[1].'</div><div class="stats-for">Short URL: <a href="'.$confUrl.'/'.$result[2].'" target="_blank">'.$confUrl.'/'.$result[2].'</a></div>';
			
			$curlObj = curl_init();
			curl_setopt($curlObj, CURLOPT_URL, 'https://www.googleapis.com/urlshortener/v1/url?key='.$resultSettings[1].'&shortUrl=http://goo.gl/'.$result[2].'&projection=FULL');
			curl_setopt($curlObj, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt($curlObj, CURLOPT_SSL_VERIFYPEER, 0);
			curl_setopt($curlObj, CURLOPT_HEADER, 0);
			$response = curl_exec($curlObj);
			
			// JSON string to object format
			$json = json_decode($response);
			
			foreach($json->analytics->allTime->countries as $country) {
				$TMPL['countries'] .= '[\''.$country->id.'\', '.$country->count.'],';
			}
			
			$i = 0;
			$class = true;
			foreach($json->analytics->allTime->referrers as $referrer) {
				if($class == true) {
					$style = 'doi';
					$class = false;
				} else {
					$style = 'unu';
					$class = true;
				}
				$TMPL['referrers'] .= '<div class='.$style.'><div class="stats-row-one"><a href="http://'.$referrer->id.'" rel="nofollow" target="_blank">'.$referrer->id.'</a></div><div class="stats-row-two">'.number_format($referrer->count, 0, '.', ',').'</div></div>';
				if($i < 5) {
					$TMPL['refJs'] .= '\''.$referrer->id.'\', ';
					$TMPL['refJsC'] .= $referrer->count.', ';
				}
				$i++;
			}
			
			$i = 0;
			$br = array('Chrome' => 'chrome.png', 'Firefox' => 'firefox.png', 'Internet Explorer' => 'ie.png', 'Opera' => 'opera.png', 'Safari' => 'safari.png', 'Mobile Safari' => 'safari.png', 'RockMelt' => 'rock.png');
			foreach($json->analytics->allTime->browsers as $browser) {
				if(array_key_exists($browser->id, $br)) {
					$brImg = true;
				} else {
					$brImg = false;
				}
				
				if($class == true) {
					$style = 'doi';
					$class = false;
				} else {
					$style = 'unu';
					$class = true;
				}
				$setBr = ($brImg == true) ? '<img src="'.$confUrl.'/images/icons/browsers/'.$br[$browser->id].'" />' : '<img src="'.$confUrl.'/images/icons/unknown.png" />';
				
				$TMPL['browsers'] .= '<div class='.$style.'><div class="stats-row-one">'.$setBr.$browser->id.'</div><div class="stats-row-two">'.number_format($browser->count, 0, '.', ',').'</div></div>';
				if($i < 5) {
					$TMPL['brJs'] .= '\''.$browser->id.'\', ';
					$TMPL['brJsC'] .= $browser->count.', ';
				}
				$i++;
			}
			
			$i = 0;
			$os = array('Windows' => 'windows.png', 'Windows NT 6.1' => 'windows.png', 'Macintosh' => 'apple.png', 'iPhone' => 'apple.png', 'iPad' => 'apple.png', 'iPod' => 'apple.png', 'Other Unix' => 'linux.png', 'Linux' => 'linux.png');
			foreach($json->analytics->allTime->platforms as $platform) {
				if(array_key_exists($platform->id, $os)) {
					$osImg = true;
				} else {
					$osImg = false;
				}
				$setOs = ($osImg == true) ? '<img src="'.$confUrl.'/images/icons/platforms/'.$os[$platform->id].'" />' : '<img src="'.$confUrl.'/images/icons/unknown.png" />';
			
				if($class == true) {
					$style = 'doi';
					$class = false;
				} else {
					$style = 'unu';
					$class = true;
				}
				$TMPL['platforms'] .= '<div class='.$style.'><div class="stats-row-one">'.$setOs.$platform->id.'</div><div class="stats-row-two">'.number_format($platform->count, 0, '.', ',').'</div></div>';
				if($i < 5) {
					$TMPL['osJs'] .= '\''.$platform->id.'\', ';
					$TMPL['osJsC'] .= $platform->count.', ';
				}
				$i++;
			}
			
			$TMPL['shortUrlHits'] = number_format($json->analytics->allTime->shortUrlClicks, 0, '.', ',');
			$TMPL['longUrlHits'] =  number_format($json->analytics->allTime->longUrlClicks, 0, '.', ',');
			
			$TMPL['shortUrlHitsToday'] = number_format($json->analytics->day->shortUrlClicks, 0, '.', ',');
			$TMPL['longUrlHitsToday'] = number_format($json->analytics->day->longUrlClicks, 0, '.', ',');
			
		} else {
			$skin = new skin('stats/error'); $all = '';
			$TMPL['pageTitle'] = '<div class="stats-for">Error</div>';
		}

		$TMPL['url'] = $confUrl;
	}
	$TMPL['titleh'] = $resultSettings[0];
	$TMPL['localurl'] = $confUrl;
	
	$all .= $skin->make();
	
	$TMPL = $TMPL_old; unset($TMPL_old);
	$TMPL['rows'] = $all;
	
	$TMPL['url'] = $confUrl;
	$TMPL['title'] = $resultSettings[0].' - Stats - '.$result[1];
	
	$skin = new skin('stats/content');
	return $skin->make();
}
?>